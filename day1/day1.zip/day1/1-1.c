#include<stdio.h>

int main()
{
    int a,b,c;
    scanf("%d",&a);
    scanf("%d",&b);
    printf("%d\n%d\n%d\n%d\n%d\n",(a+b),a*b,a-b,a/b,a%b);
    return 0;
}
