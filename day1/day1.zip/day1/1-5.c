#include<stdio.h>

int main()
{
    double a,b,c;
    scanf("%lf",&a);
    scanf("%lf",&b);
    scanf("%lf",&c);
    printf("%.1lf",a*(c-b)*4184);
    return 0;
}
