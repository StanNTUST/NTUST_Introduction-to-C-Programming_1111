#include<stdio.h>

int main()
{
    float a,b,c;
    scanf("%f",&a);
    scanf("%f",&b);
    scanf("%f",&c);
    printf("%.2f",a/b*c);
    return 0;
}
