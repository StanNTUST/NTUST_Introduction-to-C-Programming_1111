#include<stdio.h>

int main()
{
    double a,b;
    scanf("%lf",&a);
    scanf("%lf",&b);
    printf("%.3lf",a*a/(2*b));
    return 0;
}
